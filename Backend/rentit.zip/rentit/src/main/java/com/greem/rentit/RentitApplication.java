package com.greem.rentit;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RentitApplication {

	public static void main(String[] args) {
		SpringApplication.run(RentitApplication.class, args);
	}

}
